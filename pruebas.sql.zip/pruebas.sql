-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 04-06-2020 a las 16:20:27
-- Versión del servidor: 5.7.26
-- Versión de PHP: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pruebas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datos_citas`
--

DROP TABLE IF EXISTS `datos_citas`;
CREATE TABLE IF NOT EXISTS `datos_citas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `color` varchar(255) NOT NULL,
  `textColor` varchar(255) NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `datos_citas`
--

INSERT INTO `datos_citas` (`id`, `title`, `description`, `color`, `textColor`, `start`, `end`) VALUES
(1, 'Cita 3', 'Cita loquesea', '#000000', '#FFFFFF', '2018-02-14 16:01:00', '2018-02-14 16:01:00'),
(10, 'Cita 12343334', 'ee', '#ff0000', '#FFFFFF', '2018-01-31 10:30:00', '2018-01-31 10:30:00'),
(9, 'Cita 35', 'e', '#883f3f', '#FFFFFF', '2018-02-07 10:30:00', '2018-02-07 10:30:00'),
(11, 'edeee', 'eedeeee', '#622727', '#FFFFFF', '2018-01-30 10:30:00', '2018-01-30 10:30:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datos_equipos`
--

DROP TABLE IF EXISTS `datos_equipos`;
CREATE TABLE IF NOT EXISTS `datos_equipos` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Tipo` varchar(30) DEFAULT NULL,
  `Ubicacion` varchar(30) DEFAULT NULL,
  `Modelo` varchar(30) DEFAULT NULL,
  `Marca` varchar(30) DEFAULT NULL,
  `CodigoU` int(11) NOT NULL,
  `Estado` varchar(30) DEFAULT NULL,
  `Garantia` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `datos_equipos`
--

INSERT INTO `datos_equipos` (`Id`, `Tipo`, `Ubicacion`, `Modelo`, `Marca`, `CodigoU`, `Estado`, `Garantia`) VALUES
(1, 'e       ', 'a                     ', 'a                     ', 'a                     ', 1, 'a                     ', 'a'),
(9, 'e', 'erere', '2322', '24s34', 12323, 'sdsds', 'sdsds');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datos_personal`
--

DROP TABLE IF EXISTS `datos_personal`;
CREATE TABLE IF NOT EXISTS `datos_personal` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(30) DEFAULT NULL,
  `Apellido` varchar(30) DEFAULT NULL,
  `CodigoU` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `datos_personal`
--

INSERT INTO `datos_personal` (`Id`, `Nombre`, `Apellido`, `CodigoU`) VALUES
(3, 'o', 'e', 4),
(2, 'e', 'a        ', 3),
(4, 'a', 'e', 1),
(5, 'u', 'y', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datos_personas`
--

DROP TABLE IF EXISTS `datos_personas`;
CREATE TABLE IF NOT EXISTS `datos_personas` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(20) DEFAULT NULL,
  `Apellido` varchar(25) DEFAULT NULL,
  `Direccion` varchar(50) DEFAULT NULL,
  `Edad` int(4) DEFAULT NULL,
  `Sexo` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `datos_personas`
--

INSERT INTO `datos_personas` (`Id`, `Nombre`, `Apellido`, `Direccion`, `Edad`, `Sexo`) VALUES
(9, 'Jon', 'Lara', 'Direcc', 24, 'M'),
(8, 'Hol', 'Ol', 'Ol', 12, 'F'),
(7, 'Hol', 'Ol', 'Ol', 12, 'F'),
(6, 'Hol', 'Ol', 'Ol', 12, 'F'),
(10, 'dede', 'cdded', 'deded', 12, 'F'),
(11, 'M', 'E', 'dsds', 13, 'F'),
(12, 'sds', '1sds', 'dsds', 12, 'F'),
(13, 'dss', 'dsd', 'dsds', 12, 'f'),
(14, 'dsds', 'dsdsd', 'dsdsds', 12, 'f'),
(15, 'sdsds', 'dssdsd', 'dsdsds', 12, 'F');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datos_tecnicos`
--

DROP TABLE IF EXISTS `datos_tecnicos`;
CREATE TABLE IF NOT EXISTS `datos_tecnicos` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(30) DEFAULT NULL,
  `Apellido` varchar(30) DEFAULT NULL,
  `CodigoU` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `datos_tecnicos`
--

INSERT INTO `datos_tecnicos` (`Id`, `Nombre`, `Apellido`, `CodigoU`) VALUES
(3, 'o   ', 'e        ', 1),
(2, 'a', 'a', 2),
(4, 'e', 'e', 3),
(5, 'e', 'e', 5),
(6, 'e', 'e', 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios_adm`
--

DROP TABLE IF EXISTS `usuarios_adm`;
CREATE TABLE IF NOT EXISTS `usuarios_adm` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Usuario` varchar(30) DEFAULT NULL,
  `Password` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Usuario` (`Usuario`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios_adm`
--

INSERT INTO `usuarios_adm` (`Id`, `Usuario`, `Password`) VALUES
(5, 'Simon', '102030'),
(6, 'Rosa', '2020');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios_pass`
--

DROP TABLE IF EXISTS `usuarios_pass`;
CREATE TABLE IF NOT EXISTS `usuarios_pass` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Usuario` varchar(30) NOT NULL,
  `Password` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios_pass`
--

INSERT INTO `usuarios_pass` (`Id`, `Usuario`, `Password`) VALUES
(1, 'Víctor', '1234'),
(2, 'Rafael', '54321'),
(3, 'Leandro', '123'),
(4, 'Juan', '12345'),
(5, 'Simon', '102030'),
(6, 'Rosa', '2020');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios_per`
--

DROP TABLE IF EXISTS `usuarios_per`;
CREATE TABLE IF NOT EXISTS `usuarios_per` (
  `Id` int(11) NOT NULL,
  `Usuario` varchar(30) DEFAULT NULL,
  `Password` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Nombre` (`Usuario`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios_per`
--

INSERT INTO `usuarios_per` (`Id`, `Usuario`, `Password`) VALUES
(3, 'Leandro       ', '123'),
(10, 'Adrian       ', '1010');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios_tec`
--

DROP TABLE IF EXISTS `usuarios_tec`;
CREATE TABLE IF NOT EXISTS `usuarios_tec` (
  `Id` int(11) NOT NULL,
  `Usuario` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Nombre` (`Usuario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios_tec`
--

INSERT INTO `usuarios_tec` (`Id`, `Usuario`, `Password`) VALUES
(1, 'Víctor       ', '1234'),
(2, 'Rafael       ', '54321'),
(4, 'Juan       ', '12345');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `usuarios_pass`
--
ALTER TABLE `usuarios_pass` ADD FULLTEXT KEY `USUARIOS` (`Usuario`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
